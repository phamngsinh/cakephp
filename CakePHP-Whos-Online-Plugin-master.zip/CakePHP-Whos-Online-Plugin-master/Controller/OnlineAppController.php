<?php
App::uses('AppController', 'Controller');
class OnlineAppController extends AppController {
}