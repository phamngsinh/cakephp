<?php
App::uses('AppModel','Model');
class OnlineAppModel extends AppModel {
}