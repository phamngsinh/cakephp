<?php
$map = array(
	1 => array(
		'000009_Google' => 'R4f563456d8d44e83876743556318cd70'),
);
?>