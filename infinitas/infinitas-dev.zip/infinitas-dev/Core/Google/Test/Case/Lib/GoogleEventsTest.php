<?php
App::uses('GoogleEvents', 'Google.Lib');
class GoogleEventsTest extends CakeTestCase {
	public function setUp() {
		parent::setUp();
	}

	public function tearDown() {
		parent::tearDown();
	}

	public function testSomething() {

	}
}