<?php
$map = array(
	1 => array(
		'000009_Contents' => 'R4f562fb9a98c4d6fb6f83ad96318cd70'),
	2 => array(
		'000091_Contents' => 'R4f60ce56c3504d42b3e434716318cd70'),
	3 => array(
		'000092_Contents' => 'R4f9d4e49d284471e8a5273816318cd70'),
	4 => array(
		'000093_Contents' => 'R4fa2f737bd044d7798b553296318cd70'),
);
?>