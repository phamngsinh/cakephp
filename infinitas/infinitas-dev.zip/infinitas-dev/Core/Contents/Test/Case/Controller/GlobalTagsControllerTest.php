<?php
App::uses('GlobalTagsController', 'Contents.Controller');

/**
 * GlobalTagsController Test Case
 *
 */
class GlobalTagsControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'plugin.contents.global_tag'
	);

/**
 * testAdminIndex method
 *
 * @return void
 */
	public function testAdminIndex() {
	}

}
