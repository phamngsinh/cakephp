<?php
class GlobalPagesControllerTest extends CakeTestCase {
	public function testSomething() {

	}
}