<?php
App::uses('GlobalContentsController', 'Contents.Controller');

/**
 * GlobalContentsController Test Case
 *
 */
class GlobalContentsControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'plugin.contents.global_content'
	);

/**
 * testAdminDashboard method
 *
 * @return void
 */
	public function testAdminDashboard() {
	}

/**
 * testAdminIndex method
 *
 * @return void
 */
	public function testAdminIndex() {
	}

/**
 * testAdminContentIssues method
 *
 * @return void
 */
	public function testAdminContentIssues() {
	}

/**
 * testAdminTransfer method
 *
 * @return void
 */
	public function testAdminTransfer() {
	}

/**
 * testAdminAdd method
 *
 * @return void
 */
	public function testAdminAdd() {
	}

/**
 * testAdminEdit method
 *
 * @return void
 */
	public function testAdminEdit() {
	}

}
