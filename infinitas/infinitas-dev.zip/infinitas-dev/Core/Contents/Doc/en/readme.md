This plugin is mostly for developers to aid development of content related data. There is however a few things that can be useful to site administrators if the plugin is being used, such as displaying possible SEO issues and customising page output.

When the Contents plugin is used all the **main** data is stored in a centeral model which simplifies things such as search and checking for content errors as there are no complicated lookups to do or worrying about finding which plugins contain content that should be monitored.
