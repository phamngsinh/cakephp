<?php
$map = array(
	1 => array(
		'000009_Assets' => 'R4f56305f4fdc4b428be83c276318cd70'),
);
?>