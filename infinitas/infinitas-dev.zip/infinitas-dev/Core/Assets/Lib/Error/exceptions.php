<?php
/**
 * Assets exceptions
 *
 * @package Infinitas.Assets.Error
 */

/**
 * JS Min Exception
 *
 * @package Infinitas.Assets.Error
 * 
 * @internal
 */
class JSMinException extends Exception {

}