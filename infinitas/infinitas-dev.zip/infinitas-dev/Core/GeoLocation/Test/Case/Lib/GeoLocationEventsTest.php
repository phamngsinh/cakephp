<?php
App::uses('GeoLocationEvents', 'GeoLocation.Lib');
class GeoLocationEventsTest extends CakeTestCase {
	public function setUp() {
		parent::setUp();
	}

	public function tearDown() {
		parent::tearDown();
	}

	public function testSomething() {

	}
}