<?php
	$config['GeoLocation'] = array();