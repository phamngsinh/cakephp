<?php
$map = array(
	1 => array(
		'000009_GeoLocation' => 'R4f56344eba2c42bf81ca43556318cd70'),
	2 => array(
		'000091_GeoLocation' => 'R51a3fba8ab90404a96b411ae6318cd70'),
);
?>