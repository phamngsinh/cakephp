<?php
class GeoLocationAppModel extends AppModel {
	
}