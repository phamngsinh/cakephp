<?php
$map = array(
	1 => array(
		'000009_Charts' => 'R4f5630ea3f3c4e629ef93de06318cd70'),
);
?>