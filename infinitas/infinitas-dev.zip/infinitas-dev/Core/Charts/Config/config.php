<?php
/**
 * Charts config
 *
 * @link http://infinitas-cms.org/infinitas_docs/Charts Infinitas Charts
 * 
 * @package Infinitas.Charts.Lib
 */
	$config['Charts'] = array(
		'default_engine' => 'Google.GoogleStatic'
	);