<?php
	App::uses('AppEvents', 'Events.Lib');

	EventCore::getInstance();

	class EventCore {
		/**
		 * Event objects
		 *
		 * @var array
		 */
		protected $_eventClasses = array();

		/**
		 * Available handlers and what eventClasses they appear in.
		 *
		 * @var array
		 */
		protected $_eventHandlerCache = array();

		/**
		 * a cache of the event names
		 *
		 * @var object
		 */
		public $eventNameCache;

		/**
		 * a cache of the handler names
		 *
		 * @var object
		 */
		public $handlerNameCache;

		/**
		 * a cache of the plugin names
		 *
		 * @var object
		 */
		public $pluginNameCache;

		private $__availablePlugins = array();

		private $__installedPlugins = array();

		private $__pluginsMap = array(
			'testEvent' => 'all',
			'setupRoutes' => 'all',
			'setupExtensions' => 'all'
		);

		private function __construct() {}

		private function __clone() {}

		/**
		 * Returns a singleton instance of the EventCore class.
		 *
		 * @return EventCore instance
		 */
		public static function getInstance() {
			static $instance = array();

			if (empty($instance)) {
				$instance[0] = new EventCore();
				$instance[0]->_loadEventHandlers();
				$instance[0]->eventNameCache = new stdClass;
			}
			return $instance[0];
		}

		/**
		 * Trigger an event or array of events
		 *
		 * @param string|array $eventName
		 * @param array $data (optional) Array of data to pass along to the event handler
		 * @return array
		 *
		 */
		static public function trigger(&$HandlerObject, $eventName, $data = array()) {
			$_this = EventCore::getInstance();

			if (!is_array($eventName)) {
				$eventName = array($eventName);
			}

			$eventNames = Set::filter($eventName);

			$return = array();
			foreach ($eventNames as $eventName) {
				$eventData = $_this->_parseEventName($eventName);
				$return[$eventData['event']] = EventCore::_dispatchEvent($HandlerObject, $eventData['scope'], $eventData['event'], $data);
			}
			return $return;
		}


		/**
		 * Get a list of plugins that will be affected by running an event
		 *
		 * This will return all plugins that have an event class but sometimes if
		 * you need to run a global trigger but want to do it one at a time this
		 * list will help out.
		 *
		 * @param string $eventName the name of the event to run
		 *
		 * @return array
		 */
		public function pluginsWith($eventName) {
			$_this = EventCore::getInstance();
			if (!isset($_this->_eventHandlerCache[$eventName])) {
				return array();
			}

			$return = array();
			foreach ($_this->_eventHandlerCache[$eventName] as $plugin) {
				$return[] = $_this->_extractPluginName($plugin);
			}

			return $return;
		}

		/**
		 * dynamically turn plugins on during a request.
		 *
		 * This can be used to turn a plugin on programatically.
		 *
		 * @param mixed $plugins single / list of plugins to turn on
		 * @param bool $allowUninstalled allow turning on a plugin that is not installed (not recommended)
		 *
		 * @return boolean
		 */
		static public function activatePlugins($plugins = array(), $allowUninstalled = false) {
			$_this = EventCore::getInstance();

			if (!is_array($plugins)) {
				$plugins = array($plugins);
			}

			if (empty($plugins)) {
				return false;
			}

			if ($allowUninstalled) {
				$_this->__installedPlugins = App::objects('plugin');
			}
			else {
				$_this->__installedPlugins = CakePlugin::loaded();
			}

			foreach ($plugins as $plugin) {
				if (in_array($plugin, $_this->__installedPlugins) && !in_array($plugin, $_this->__availablePlugins)) {
					$_this->__availablePlugins[] = $plugin;
				}
			}

			return true;
		}

		/**
		 * check if a plugin is active for the current request
		 *
		 * This method is used within the core to stop people accessing the controllers
		 * and actions directly. It can also be used to see if plugins are active
		 * for the request. Even if something is installed and active, it may have
		 * been dynamically turned off (or the other way round)
		 *
		 * @param string $plugin the name of the plugin to check
		 *
		 * @return boolean
		 */
		public function isPluginActive($plugin) {
			$_this = EventCore::getInstance();
			if (!$plugin || !in_array(Inflector::camelize($plugin), $_this->__availablePlugins)) {
				return false;
			}

			return true;
		}

		/**
		 * Loads all available event handler classes for enabled plugins
		 *
		 */
		protected function _loadEventHandlers() {
			$this->_eventHandlerCache = Cache::read('event_handlers', 'events');

			if (!empty($this->_eventHandlerCache)) {
				return;
			}

			$plugins = CakePlugin::loaded();
			foreach ((array)$plugins as $pluginName) {
				self::loadEventHandler($pluginName);
			}

			Cache::write('event_handlers', $this->_eventHandlerCache, 'events');
		}

		public static function loadEventHandler($plugin) {
			$_this = self::getInstance();
			$filename = App::pluginPath($plugin) . 'Lib' . DS . $plugin . 'Events.php';
			$className = $plugin . 'Events';

			if (file_exists($filename)) {
				if ($_this->_loadEventClass($className, $filename)) {
					$_this->_getAvailableHandlers($_this->_eventClasses[$className]);
				}
			}
		}

		/**
		 * Dispatch Event
		 *
		 * @param string $eventName
		 * @param array $data (optional)
		 * @return array
		 *
		 */
		static protected function _dispatchEvent(&$HandlerObject, $scope, $eventName, $data = array()) {
			$shouldCache = true;
			if (array_key_exists('cache', (array)$data) && $data['cache'] == false) {
				$shouldCache = false;
			}

			if ($shouldCache) {
				$cacheName = cacheName('event_' . $scope, array(
					'scope' => $scope,
					'event' => $eventName,
					'data' => $data
				));
				$cache = Cache::read($cacheName, 'events');
				if ($cache !== false) {
					return $cache;
				}
			}
			$_this = EventCore::getInstance();
			$eventHandlerMethod = $_this->_handlerMethodName($eventName);

			$return = array();
			if (isset($_this->_eventHandlerCache[$eventName])) {
				foreach ($_this->_eventHandlerCache[$eventName] as $eventClass) {
					$pluginName = $_this->_extractPluginName($eventClass);

					$pluginType = 'loaded';
					if (isset($_this->__pluginsMap[$eventName])) {
						$pluginType = $_this->__pluginsMap[$eventName];
					}

					if (!in_array(Inflector::camelize($pluginName), (array)InfinitasPlugin::listPlugins($pluginType))) {
						continue;
					}

					if (($scope == 'Global' || $scope == $pluginName)) {
						$_this->_loadEventClass($eventClass);
						$Event = new Event($eventName, $HandlerObject, $pluginName);

						$return[$pluginName] = call_user_func_array(array($_this->_eventClasses[$eventClass], $eventHandlerMethod), array($Event, $data));
					}
				}
			}

			if ($shouldCache) {
				Cache::write($cacheName, $return, 'events');
			}

			return $return;
		}

		/**
		 * takes the event name and breaks it down into the different parts setting
		 * some defaults for gloabl events. results are cached to avoid importing
		 * and alling the string class to much.
		 *
		 * @param string $eventName the name of the event
		 * @return array
		 */
		protected function _parseEventName($eventName) {
			$_this = EventCore::getInstance();

			if (!isset($_this->eventNameCache->{$eventName})) {
				$eventTokens = String::tokenize($eventName, '.');
				$scope = 'Global';
				$event = $eventTokens[0];
				if (count($eventTokens) > 1) {
					list($scope, $event) = $eventTokens;

					if ($scope != Inflector::camelize($scope)) {
						user_error(sprintf('%s.%s is not valid, camelized plugins required', $scope, $event));
						$scope = Inflector::camelize($scope, E_USER_NOTICE);
					}
				}
				$array = (array)$_this->eventNameCache;
				$array[$eventName] = array(
					'scope' => $scope,
					'event' => $event
				);

				$_this->eventNameCache = (object)$array;
			}

			return $_this->eventNameCache->{$eventName};
		}

		/**
		 * Converts event name into a handler method name and caches the result
		 * so that there are less calls to the inflector method.
		 *
		 * @param string $eventName
		 * @return string
		 *
		 */
		protected function _handlerMethodName($eventName) {
			$_this = EventCore::getInstance();
			if (!isset($_this->handlerNameCache->{$eventName})) {
				$array = (array)$_this->handlerNameCache;
				$array[$eventName] = 'on' . Inflector::camelize($eventName);

				$_this->handlerNameCache = (object)$array;
			}

			return $_this->handlerNameCache->{$eventName};
		}

		/**
		 * Loads list of available event handlers in a event object
		 *
		 * @param object $Event
		 */
		protected function _getAvailableHandlers($Event) {
			if (is_object($Event)) {
				$_this = EventCore::getInstance();

				$reflection = new ReflectionClass($Event);
				$classMethods = array_filter($reflection->getMethods(), create_function('$v', 'return $v->class == "'.get_class($Event).'" && substr($v->name, 0, 2) == "on";'));
				$handlers = array_map(create_function('$v', 'return lcfirst(substr($v->name, 2));'), $classMethods);

				foreach ($handlers as $handlerName) {
						$_this->_eventHandlerCache[$handlerName][] = get_class($Event);
				}
			}
		}

		/**
		 * Loads and initialises an event class
		 *
		 * @param string $className the event class to load
		 * @param string $filename the file name of the event
		 */
		protected function _loadEventClass($className, $filename = false) {
			$_this = EventCore::getInstance();
			if (isset($_this->_eventClasses[$className]) && is_object($_this->_eventClasses[$className])) {
				return true;
			}

			if ($filename === false) {
				$baseName = Inflector::underscore($className) . '.php';
				$pluginName = Inflector::camelize(preg_replace('/events.php$/i', '', $baseName));
				$pluginPath = App::pluginPath($pluginName);
				$filename = $pluginPath . $baseName;
			}
			if (empty($pluginName)) {
				$baseName = Inflector::underscore($className) . '.php';
				$pluginName = Inflector::camelize(preg_replace('/events.php$/i', '', $baseName));
			}

			require $filename;

			try{
				$_this->_eventClasses[$className] = new $className();
				return true;
			}
			catch(Exception $e) {
				$this->log(serialize($e), 'core');
				return false;
			}
		}

		/**
		 * Extracts the plugin name out of the class name and caches the value
		 * so that the strtolower and other stuff does not need to be called
		 * so many times.
		 *
		 * @param string $className the name of the class being called
		 * @return string
		 */
		protected function _extractPluginName($className) {
			$_this = EventCore::getInstance();
			if (!isset($_this->pluginNameCache->{$className})) {
				$array = (array)$_this->pluginNameCache;
				$array[$className] = substr($className, 0, strlen($className) - 6);

				$_this->pluginNameCache = (object)$array;
			}

			return $_this->pluginNameCache->{$className};
		}
	}

	/**
	 * Event Object
	 */
	class Event {

		/**
		 * Contains assigned values
		 *
		 * @var array
		 *
		protected $values = array();*/

		/**
		 * Constructor with EventName and EventData (optional)
		 *
		 * Event Data is automaticly assigned as properties by array key
		 *
		 * @param string $eventName Name of the Event
		 * @param array $data optional array with k/v data
		 */
		public function __construct($eventName, $HandlerObject, $pluginName) {
			$this->name = $eventName;
			$this->Handler = $HandlerObject;
			$this->plugin = $pluginName;
		}
	}