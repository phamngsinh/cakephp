<?php
/**
 * fixture file for TimeZone tests.
 *
 * @package Contact.Fixture
 * @since 0.9b1
 */
class TimeZoneFixture extends CakeTestFixture {

	public $name = 'TimeZone';

	public $fields = array(
		'indexes' => array(

		),
		'tableParameters' => array()
	);

	public $records = array(
	);
}