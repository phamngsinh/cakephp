<?php
/**
 * ContactEventsTest
 *
 * These tests are extended from InfinitasEventTestCase which does most of the
 * automated testing for simple events
 */

App::uses('InfinitasEventTestCase', 'Events.Test/Lib');

class ContactEventsTest extends InfinitasEventTestCase {

}