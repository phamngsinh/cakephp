<?php
	$config['Contact'] = array(
		'continents' => array(
			1 => 'Africa',
			'Antarctica',
			'Asia',
			'Australia',
			'Europe',
			'North America',
			'South America'
		),
		'phone_regex' => '/\D?(\d{3})\D?\D?(\d{3})\D?(\d{4})$/',
		'phone_regex' => '/\D?(\d{3})\D?\D?(\d{3})\D?(\d{4})$/',
	);