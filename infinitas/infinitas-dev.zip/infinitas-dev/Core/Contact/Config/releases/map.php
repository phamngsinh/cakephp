<?php
$map = array(
	1 => array(
		'000009_Contact' => 'R4f56323e260c44679ec440726318cd70'),
	2 => array(
		'000091_Contact' => 'R4fdf1936e2ac4687a9a93c866318cd70'),
	3 => array(
		'000092_Contact' => 'R509b147597004cbeb25209466318cd70'),
);
?>