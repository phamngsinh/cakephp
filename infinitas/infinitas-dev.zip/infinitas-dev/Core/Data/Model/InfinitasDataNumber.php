<?php
class InfinitasDataNumber extends DataAppModel {
	
}