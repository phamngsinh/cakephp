<?php
class DataAppModel extends AppModel {
	
}