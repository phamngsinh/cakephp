<?php
class InfinitasDataDate extends DataAppModel {
	
}