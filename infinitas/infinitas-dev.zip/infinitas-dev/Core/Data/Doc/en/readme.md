The Data plugin provides various classes that make working with data in different formats a bit simpler. Some examples include import and export of `CSV` data. It also provides ways of dealing with large amounts of data through the `BigDataBehavior`.

This plugin is aimed at developers and does not offer much in the way of the end user directly.