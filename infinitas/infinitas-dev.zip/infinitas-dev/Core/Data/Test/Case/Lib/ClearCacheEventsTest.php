<?php
App::uses('ClearCacheEvents', 'ClearCache.Lib');
class ClearCacheEventsTest extends CakeTestCase {
	public function setUp() {
		parent::setUp();
	}

	public function tearDown() {
		parent::tearDown();
	}

	public function testSomething() {

	}
}