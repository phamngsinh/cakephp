<?php
$map = array(
	1 => array(
		'000009_Data' => 'R4f5632d5c7644004807341d06318cd70'),
);
?>