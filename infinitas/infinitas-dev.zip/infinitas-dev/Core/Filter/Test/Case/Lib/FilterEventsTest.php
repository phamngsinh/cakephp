<?php
App::uses('FilterEvents', 'Filter.Lib');
class FilterEventsTest extends CakeTestCase {
	public function setUp() {
		parent::setUp();
	}

	public function tearDown() {
		parent::tearDown();
	}

	public function testSomething() {

	}
}