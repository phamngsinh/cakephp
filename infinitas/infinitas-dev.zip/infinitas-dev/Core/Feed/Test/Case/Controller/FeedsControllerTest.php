<?php
class FeedsControllerTest extends CakeTestCase {
	public function testSomething() {

	}
}