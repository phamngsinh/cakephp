<?php
App::uses('FeedEvents', 'Feed.Lib');
class FeedEventsTest extends CakeTestCase {
	public function setUp() {
		parent::setUp();
	}

	public function tearDown() {
		parent::tearDown();
	}

	public function testSomething() {

	}
}