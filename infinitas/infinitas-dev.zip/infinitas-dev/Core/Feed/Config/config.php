<?php
$config['Feed'] = array(
	'time_format' => 'jS M Y',
);