<?php
$map = array(
	1 => array(
		'000009_Feed' => 'R4f56342fab9c4c2c9a6743556318cd70'),
);
?>