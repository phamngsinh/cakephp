<?php
class MailSystemTest extends CakeTestCase {
	public function testSomething() {
		
	}
}
