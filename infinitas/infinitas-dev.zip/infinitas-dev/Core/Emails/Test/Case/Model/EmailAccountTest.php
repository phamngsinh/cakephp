<?php
class EmailAccountTest extends CakeTestCase {
	public function testSomething() {

	}
}
