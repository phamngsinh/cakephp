<?php
class EmailAccountsControllerTest extends CakeTestCase {
	public function testSomething() {

	}
}
