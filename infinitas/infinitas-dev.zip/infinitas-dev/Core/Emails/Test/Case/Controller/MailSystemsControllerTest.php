<?php
class MailSystemsControllerTest extends CakeTestCase {
	public function testSomething() {
		
	}
}
