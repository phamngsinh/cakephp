<?php
/**
 * fixture file for MailSystem tests.
 *
 * @package Emails.Fixture
 * @since 0.9b1
 */
class MailSystemFixture extends CakeTestFixture {
	public $name = 'MailSystem';

	public $fields = array(
		'indexes' => array(
			
		),
		'tableParameters' => array()
	);

	public $records = array(
	);
}