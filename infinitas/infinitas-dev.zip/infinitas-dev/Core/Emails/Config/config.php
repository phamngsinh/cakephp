<?php
	 $config['Email'] = array(
		 'info' => array(
			 'general' => __d('email', 'Manage email accounts'),
			 'accounts' => __d('email', 'These are all the accounts that you have access to. You can click an account to view its mail.')
		 )
	 );
