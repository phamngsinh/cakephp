<?php
$map = array(
	1 => array(
		'000009_Configs' => 'R4f5631b1aee04be5a6603fac6318cd70'),
);
?>