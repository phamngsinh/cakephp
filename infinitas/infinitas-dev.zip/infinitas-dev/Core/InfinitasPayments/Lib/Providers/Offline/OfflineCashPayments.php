<?php
App::uses('OfflineSocket', 'InfinitasPayments.Lib/Providers/Offline');

class OfflineCashPayments extends OfflineSocket {
	
}