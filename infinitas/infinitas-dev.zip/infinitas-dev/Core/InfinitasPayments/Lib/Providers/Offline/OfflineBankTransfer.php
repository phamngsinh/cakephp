<?php
App::uses('OfflineSocket', 'InfinitasPayments.Lib/Providers/Offline');

class OfflineBankTransfer extends OfflineSocket {
	
}