<?php

class InfinitasPaymentsAppController extends AppController {

}

