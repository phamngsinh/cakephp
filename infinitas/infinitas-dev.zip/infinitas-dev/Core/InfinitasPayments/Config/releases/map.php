<?php
$map = array(
	1 => array(
		'000001_InfinitasPayments' => 'R50ea0f6600bc4850bc0154fd6318cd70'),
	2 => array(
		'000011_InfinitasPayments' => 'R50efe21e085046bfb76b1e826318cd70'),
);
?>