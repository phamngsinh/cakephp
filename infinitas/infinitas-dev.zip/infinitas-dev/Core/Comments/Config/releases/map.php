<?php
$map = array(
	1 => array(
		'000009_Comments' => 'R4f56311fab8c4221afbf3e906318cd70'),
	2 => array(
		'000091_Comments' => 'R4fbabc4eff8c4a3899594a0a6318cd70'),
	3 => array(
		'000092_Comments' => 'R50ff2dd3f4084927b0564a6e6318cd70'),
);
?>