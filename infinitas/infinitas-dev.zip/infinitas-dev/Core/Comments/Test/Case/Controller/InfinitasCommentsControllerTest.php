<?php
App::uses('InfinitasCommentsController', 'Comments.Controller');

/**
 * InfinitasCommentsController Test Case
 *
 */
class InfinitasCommentsControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'plugin.comments.infinitas_comment',
		'plugin.comments.infinitas_comment_attribute'
	);

/**
 * testIndex method
 *
 * @return void
 */
	public function testIndex() {
	}

/**
 * testAdminMass method
 *
 * @return void
 */
	public function testAdminMass() {
	}

/**
 * testAdminIndex method
 *
 * @return void
 */
	public function testAdminIndex() {
	}

/**
 * testAdminReply method
 *
 * @return void
 */
	public function testAdminReply() {
	}

/**
 * testAdminBan method
 *
 * @return void
 */
	public function testAdminBan() {
	}

/**
 * testAdminCommentPurge method
 *
 * @return void
 */
	public function testAdminCommentPurge() {
	}

}
