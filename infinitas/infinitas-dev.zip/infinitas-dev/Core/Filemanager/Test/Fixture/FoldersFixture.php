<?php
/**
 * fixture file for Folders tests.
 *
 * @package Filemanager.Fixture
 * @since 0.9b1
 */
class FoldersFixture extends CakeTestFixture {
	public $name = 'Folders';

	public $fields = array(
		'indexes' => array(
			
		),
		'tableParameters' => array()
	);

	public $records = array(
	);
}