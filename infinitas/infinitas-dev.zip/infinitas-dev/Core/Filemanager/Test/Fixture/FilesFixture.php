<?php
/**
 * fixture file for Files tests.
 *
 * @package Filemanager.Fixture
 * @since 0.9b1
 */
class FilesFixture extends CakeTestFixture {
	public $name = 'Files';

	public $fields = array(
		'indexes' => array(
			
		),
		'tableParameters' => array()
	);

	public $records = array(
	);
}