<?php
App::uses('FilemanagerEvents', 'Filemanager.Lib');
class FilemanagerEventsTest extends CakeTestCase {
	public function setUp() {
		parent::setUp();
	}

	public function tearDown() {
		parent::tearDown();
	}

	public function testSomething() {

	}
}