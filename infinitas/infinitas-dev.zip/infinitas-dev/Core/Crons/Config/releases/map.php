<?php
$map = array(
	1 => array(
		'000009_Crons' => 'R4f56329cf3704420925841436318cd70'),
);
?>