# CKEditor

Plugin for integrating [CKEDitor](http://ckeditor.com/) into [Croogo](http://croogo.org).

Requires Croogo v1.5 or higher

## Installation

Clone/Upload the content of this repository to /app/Plugin/Ckeditor, and activate the plugin from your admin panel.
