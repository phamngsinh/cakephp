<?php

App::uses('CroogoErrorController', 'Croogo.Controller');

class CakeErrorController extends CroogoErrorController {

}
