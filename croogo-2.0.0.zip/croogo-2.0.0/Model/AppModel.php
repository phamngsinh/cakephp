<?php

App::uses('CroogoAppModel', 'Croogo.Model');

/**
 * Base Application model
 *
 * @package  Croogo
 * @link     http://www.croogo.org
 */
class AppModel extends CroogoAppModel {

}
