$(document).ready(function(){
	$('.flash-msg').delay(5000).fadeOut('slow');
});

