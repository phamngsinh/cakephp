<?php
class WebTechNickAppModel extends AppModel {
}
?>