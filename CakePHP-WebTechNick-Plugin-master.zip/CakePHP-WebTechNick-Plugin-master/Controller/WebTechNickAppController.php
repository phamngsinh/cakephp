<?php
class WebTechNickAppController extends AppController {
}
?>