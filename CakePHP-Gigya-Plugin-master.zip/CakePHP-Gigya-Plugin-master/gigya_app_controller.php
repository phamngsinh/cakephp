<?php
class GigyaAppController extends AppController {

}
?>