<?php
class GigyaAppModel extends AppModel {

}
?>