<?php

class CloudFilesAppModel extends AppModel {

}

