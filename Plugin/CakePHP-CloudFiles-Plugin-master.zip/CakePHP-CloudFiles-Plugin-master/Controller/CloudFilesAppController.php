<?php

class CloudFilesAppController extends AppController {

}

