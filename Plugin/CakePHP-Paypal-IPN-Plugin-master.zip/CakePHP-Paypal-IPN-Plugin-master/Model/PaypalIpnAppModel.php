<?php
App::uses('AppModel','Model');
class PaypalIpnAppModel extends AppModel {
  
}