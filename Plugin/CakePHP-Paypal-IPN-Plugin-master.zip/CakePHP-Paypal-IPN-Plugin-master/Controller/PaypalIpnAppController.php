<?php
App::uses('AppController','Controller');
class PaypalIpnAppController extends AppController {
  
}