<?php
class ConfigurationAppModel extends AppModel{
}
?>