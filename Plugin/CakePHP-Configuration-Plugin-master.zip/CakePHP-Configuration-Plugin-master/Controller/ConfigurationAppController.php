<?php
class ConfigurationAppController extends AppController {
}
?>