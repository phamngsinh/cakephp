CKEDITOR.plugins.setLang('grafikart', 'fr',
{
	grafikart:
	{
		title: 'Ajouter un medium',
	}
});
