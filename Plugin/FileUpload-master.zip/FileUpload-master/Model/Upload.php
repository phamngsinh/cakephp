<?php  
class Upload extends FileUploadAppModel {
}
?>