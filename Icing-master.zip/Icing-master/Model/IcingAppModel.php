<?php
App::uses('AppModel', 'Model');
class IcingAppModel extends AppModel {

}

