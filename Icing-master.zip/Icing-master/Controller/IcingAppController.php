<?php

class IcingAppController extends AppController {

}

